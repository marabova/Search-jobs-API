﻿
function loadJobs(resultsWrapper, job) {
    var jobBoxWrapper = $('<div class="job panel panel-default"></div>');
    var jobBoxContent = $('<div class="panel-body"></div>')
    var jobTitle = $('<div class="panel-heading"><h5>' + job.position_title + '</h5></div>');
    var jobLocation = $('<p>' + job.locations + '</p>');
    var jobOrganisation = $('<p>' + job.organization_name + '</p>');
    var viewMore = $('<p><a href="' + job.url + '" target="_blank"> View more</a><p>')
    jobBoxContent.append(jobLocation, jobOrganisation, viewMore);
    jobBoxWrapper.append(jobTitle, jobBoxContent);
    resultsWrapper.append(jobBoxWrapper);
}

$(document).ready(function () {
    var resultsWrapper = $('#jobsResults');

    $("#searchForm").submit(function (event) {
        /** Prevent submiting the form*/
        event.preventDefault();

        var stringResult = $(this).serialize();
         /** Replacing symbols in the string*/
        var results = stringResult.replace(/[=&]/g, '+').replace(/location/g, '');

        /** 
         * Ajax call to API
         * @results: Seriliazed data from the form
        */
        $.ajax({
            url: 'https://jobs.search.gov/jobs/search.json?query=' + results,
            success: function (data) {
                if (data.length === 0) {
                    var noResult = $('<div class="job panel panel-default"><div class="panel-heading"><h5><span class="glyphicon glyphicon-minus-sign"></span>  No results found for this request! Please try again</h5></div></div>');
                    resultsWrapper.append(noResult);
                } else {
                    $.each(data, function (index, value) {
                        loadJobs(resultsWrapper, value);
                    });
                }
                $('.btnContainer').removeClass('hidden');

            },
            dataType: 'json'
        });
    });

    /** 
     * Change the view - grid or list 
    */
    $('.btnContainer .btn').on('click', function (e) {
        if ($(this).hasClass('listView')) {
            resultsWrapper.removeClass('gridView').addClass('listView');
        }
        else if ($(this).hasClass('gridView')) {
            resultsWrapper.removeClass('listView').addClass('gridView');
        }
    });
});